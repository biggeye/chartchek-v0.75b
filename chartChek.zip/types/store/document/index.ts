import { Leaf } from "lucide-react"
import * as z from 'zod';

interface DocumentStoreState {
    documents: Document[];
    isLoading: boolean;
    error: string | null;
    fileQueue: Document[];
  }
  
  interface DocumentMetadata {
    notes: string;
    tags: string[];
    category: string;
  }

  interface TextContentBlockParam {
    type: "text";
    text: string;
  }
  
  interface FileSearchTool {
    type: "file_search";
  }
  
  interface MessageAttachment {
    file_id: string;
    tools: FileSearchTool[]; // now each tool is guaranteed to be a FileSearch tool
  }
  
  interface MessagePayload {
    role: "user" | "assistant";
    content: string | TextContentBlockParam[];
    attachments?: MessageAttachment[] | null;
    metadata?: Record<string, string>;
  }
  
  
  
  interface Document {
    document_id: string;
    facility_id?: string;
    fileName?: string;
    fileType?: string;
    fileSize?: number;
    filePath: z.infer<typeof filePathSchema>;
    bucket?: string;
    createdAt?: string;
    updatedAt?: string;
    userId?: string;
    processingStatus?: 'pending' | 'processing' | 'indexed' | 'failed' | 'unsupported_format' | string;
    processingError?: string;
    metadata?: DocumentMetadata[];
    openai_file_id?: string;
  }

const filePathSchema = z.string().min(1);

  interface DocumentStore extends DocumentStoreState {
    setLoading: (isLoading: boolean) => void;
    setError: (error: string | null) => void;
    fetchDocuments: () => any;
    addToFileQueue: (file: Document) => void;
    removeFromFileQueue: (file: Document) => void;
    uploadFileToOpenAI: (file: Document) => Promise<string>;
    uploadDocument: (file: File) => Promise<Document | null>;
    uploadAndProcessDocument: (file: File) => Promise<Document | null>;
  }

interface VectorStore {
    id: string;
    object: string;
    created_at: number;
    usage_bytes: number;
    last_active_at: number;
    name: string;
    status: string;
    file_counts: {
        in_progress: number;
        completed: number;
        cancelled: number;
        failed: number;
        total: number;
    };
    metadata: {};
    last_used_at: number;
}

interface VectorStoreFile {
    id: string;
    object: string;
    usage_bytes: number;
    created_at: number;
    vector_store_id: string;
    status: string;
    last_error: null;
    chunking_strategy: {
        type: string;
        static: {
            max_chunk_size_tokens: number;
            chunk_overlap_tokens: number;
        }
    }
}

interface VectorStoreFileBatch {
    id: string;
    object: string;
    created_at: number;
    vector_store_id: string;
    status: string;
    file_counts: {
        in_progress: number;
        completed: number;
        failed: number;
        cancelled: number;
        total: number;
    }
}

export type {
  MessagePayload,
    DocumentStoreState,
    DocumentMetadata,
    Document,
    DocumentStore,
    VectorStore,
    VectorStoreFile,
    VectorStoreFileBatch,
};