'use client'

export default function AccountPage() {
    return (
        <div>
            Account
        </div>
    )
}
