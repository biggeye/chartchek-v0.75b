'use client'

import Chat from "@/components/chat/Chat"


export default function CompliancePage() {

  return (
    <div>
      <Chat assistantId="asst_9RqcRDt3vKUEFiQeA0HfLC08" />
    </div>
  )
}