'use client'

import Chat from "@/components/chat/Chat"

export default function BillingPage() {

    return (
        <div>
        <Chat assistantId="asst_7rzhAUWAamYufZJjZeKYkX1t" />
        </div>
    )
}