<?php
// Simple PHP test file
phpinfo();
?>
